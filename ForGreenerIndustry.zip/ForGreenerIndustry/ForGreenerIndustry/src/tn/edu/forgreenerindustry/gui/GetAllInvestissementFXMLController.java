/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.edu.forgreenerindustry.gui;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import tn.edu.forgreenerindustry.entities.Investissement;
import tn.edu.forgreenerindustry.services.ServiceInvestissement;
import tn.edu.forgreenerindustry.tools.Pdf;

/**
 * FXML Controller class
 *
 * @author milou
 */
public class GetAllInvestissementFXMLController implements Initializable {

    @FXML
    private TableColumn<Investissement, String> colMontant;
    @FXML
    private TableColumn<Investissement, Date> colDate;
    @FXML
    private TableColumn<Investissement, String> colDuree;
    @FXML
    private TableColumn<Investissement, String> colDetails;
    @FXML
    private TableColumn<Investissement, String> colStatus;
    @FXML
    private TableColumn<Investissement, String> colInvestisseur;
    @FXML
    private TableColumn<Investissement, String> colNomEntreprise;
    @FXML
    private TableView<Investissement> tvAfficherInvestissement;
    
    private ServiceInvestissement service;
    @FXML
    private Button retour;
    private static String FILE = "C:\\Users\\milou\\Desktop\\output.pdf";


    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colMontant.setCellValueFactory(new PropertyValueFactory("montant"));
        colDate.setCellValueFactory(new PropertyValueFactory("date_debut_investissement"));
        colDuree.setCellValueFactory(new PropertyValueFactory("duree_prevue"));
        colDetails.setCellValueFactory(new PropertyValueFactory("details"));
        colStatus.setCellValueFactory(new PropertyValueFactory("status"));
        colInvestisseur.setCellValueFactory(new PropertyValueFactory("id_investisseur"));
        colNomEntreprise.setCellValueFactory(new PropertyValueFactory("id_entreperise"));
    
    service = new ServiceInvestissement();
    loadInvestissementData();
    }    
       
    
    public void loadInvestissementData() {
        ObservableList<Investissement> evenementList = FXCollections.observableArrayList(service.getAll(null));
        tvAfficherInvestissement.setItems(evenementList);
    }

    @FXML
    private void btnRetour(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AccueilFXML.fxml"));
            Parent root = loader.load();
            Scene accueilFXMLScene = new Scene(root);
            Stage stage = (Stage) retour.getScene().getWindow();
            stage.setScene(accueilFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
@FXML
    public void pdf() throws FileNotFoundException, DocumentException{
        ServiceInvestissement se=new ServiceInvestissement();
        try
        {
        List<Investissement> list = se.getAll(null);
                        Document document = new Document();
                        PdfWriter.getInstance(document, new FileOutputStream(FILE));
                        document.open();
                        Pdf.addMetaData(document);
                        Pdf.addTitlePage(document, list);
                        document.close();
        }
        catch (Exception ex) {
                    System.out.println(ex);
                 }
        
    }
    
}
