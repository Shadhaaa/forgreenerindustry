/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.edu.forgreenerindustry.gui;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import tn.edu.forgreenerindustry.entities.Investissement;
import tn.edu.forgreenerindustry.services.ServiceInvestissement;


/**
 * FXML Controller class
 *
 * @author milou
 */
public class ChercherInvestissementFXMLController implements Initializable {

    @FXML
    private TableColumn<Investissement, String> colMontant;
    @FXML
    private TableColumn<Investissement, Date> colDate;
    @FXML
    private TableColumn<Investissement, String> colDuree;
    @FXML
    private TableColumn<Investissement, String> colDetails;
    @FXML
    private TableColumn<Investissement, String> colStatus;
    @FXML
    private TableColumn<Investissement, String> colInvestisseur;
    @FXML
    private TableColumn<Investissement, String> colNomEntreprise;
    @FXML
    private TextField tfRechercheDate;
    @FXML
    private Label resultatRecherche;
    @FXML
    private Button retour;
    @FXML
    private Button chercher;
    @FXML
    private TableView<Investissement> tvChercherInvestissement;
     
    private ObservableList<Investissement> ResultatRecherche;

    
    /**
     * Initializes the controller class.
     */
    

    @FXML
    private void btnChercher(ActionEvent event) {
    String date_investissement = tfRechercheDate.getText();
    ServiceInvestissement service = new ServiceInvestissement();
    List<Investissement> evenements = service.getInvestissementByCls(date_investissement);
    ResultatRecherche.clear();
    ResultatRecherche.addAll(evenements);
    if (evenements.isEmpty()) {
        resultatRecherche.setText("Aucun investissement avec ces mots: " + date_investissement);
    } else {
        resultatRecherche.setText("Oui il existe un investissement avec ces mots: " + date_investissement);
    }
    tvChercherInvestissement.setItems(ResultatRecherche); // Update the TableView

    }
    @FXML
    private void tfRecherche(KeyEvent event) {
    String date_investissement = tfRechercheDate.getText();
    ServiceInvestissement service = new ServiceInvestissement();
    List<Investissement> evenements = service.getInvestissementByCls(date_investissement);
    ResultatRecherche.clear();
    ResultatRecherche.addAll(evenements);
    if (evenements.isEmpty()) {
        resultatRecherche.setText("Aucun investissement avec ces mots: " + date_investissement);
    } else {
        resultatRecherche.setText("Oui il existe un investissement avec ces mots: " + date_investissement);
    }
    tvChercherInvestissement.setItems(ResultatRecherche); // Update the TableView

    }



    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        colMontant.setCellValueFactory(new PropertyValueFactory("montant"));
        colDate.setCellValueFactory(new PropertyValueFactory("date_debut_investissement"));
        colDuree.setCellValueFactory(new PropertyValueFactory("duree_prevue"));
        colDetails.setCellValueFactory(new PropertyValueFactory("details"));
        colStatus.setCellValueFactory(new PropertyValueFactory("status"));
        colInvestisseur.setCellValueFactory(new PropertyValueFactory("id_investisseur"));
        colNomEntreprise.setCellValueFactory(new PropertyValueFactory("id_entreperise"));
    
    ResultatRecherche = FXCollections.observableArrayList();
    tvChercherInvestissement.setItems(ResultatRecherche);
    }
    @FXML
    private void btnRetour(ActionEvent event) {
          try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AccueilFXML.fxml"));
            Parent root = loader.load();
            Scene accueilFXMLScene = new Scene(root);
            Stage stage = (Stage) retour.getScene().getWindow();
            stage.setScene(accueilFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}