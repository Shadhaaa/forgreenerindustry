/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.edu.forgreenerindustry.gui;

import com.itextpdf.text.DocumentException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import tn.edu.forgreenerindustry.entities.Evenement;
import tn.edu.forgreenerindustry.services.ServiceEvenement;
import tn.edu.forgreenerindustry.tools.Pdf;

/**
 * FXML Controller class
 *
 * @author milou
 */
public class GetAllEvenementFXMLController implements Initializable {

    @FXML
    private TableColumn<Evenement,String> colTitre;
    @FXML
    private TableColumn<Evenement ,Date> colDate;
    @FXML
    private TableColumn<Evenement ,String> colQRcode;
    @FXML
    private TableColumn<Evenement, String> colImage;
    @FXML
    private TableColumn<Evenement, String> colLieu;
    @FXML
    private TableColumn<Evenement, String> colDescription;
    @FXML
    private TableColumn<Evenement, String> colNomEntreprise;
    @FXML
    private TableView<Evenement> tvAllEvenement;
    
    private ServiceEvenement service;
    @FXML
    private Button retour;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    colTitre.setCellValueFactory(new PropertyValueFactory("titre_evenement"));
    colDate.setCellValueFactory(new PropertyValueFactory("date_evenement"));
    colQRcode.setCellValueFactory(new PropertyValueFactory("QRcode"));
    colImage.setCellValueFactory(new PropertyValueFactory("image_evenement"));
    colLieu.setCellValueFactory(new PropertyValueFactory("lieu_evenement"));
    colDescription.setCellValueFactory(new PropertyValueFactory("description_evenement"));
    colNomEntreprise.setCellValueFactory(new PropertyValueFactory("id_entreperise"));
    
    service = new ServiceEvenement();
    loadEvenementData();
    }    
       
    
    public void loadEvenementData() {
        ObservableList<Evenement> evenementList = FXCollections.observableArrayList(service.getAll(null));
        tvAllEvenement.setItems(evenementList);
    }

    @FXML
    private void btnRetour(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AccueilFXML.fxml"));
            Parent root = loader.load();
            Scene accueilFXMLScene = new Scene(root);
            Stage stage = (Stage) retour.getScene().getWindow();
            stage.setScene(accueilFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    

    
}
