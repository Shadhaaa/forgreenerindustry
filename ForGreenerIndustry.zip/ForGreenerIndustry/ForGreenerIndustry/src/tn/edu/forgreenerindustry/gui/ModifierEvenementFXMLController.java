/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.edu.forgreenerindustry.gui;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import tn.edu.forgreenerindustry.entities.Evenement;
import tn.edu.forgreenerindustry.services.ServiceEvenement;

/**
 * FXML Controller class
 *
 * @author milou
 */
public class ModifierEvenementFXMLController implements Initializable {

    @FXML
    private TableView<Evenement> tvModifierEvenement;
    @FXML
    private TextField tfTitre;
    @FXML
    private TextField tfQRcode;
    @FXML
    private TextField tfImage;
    @FXML
    private TextField tfLieu;
    @FXML
    private TextField tfDescription;
    @FXML
    private TextField tfNomEntreprise;
    @FXML
    private TableColumn<Evenement,String> colTitre;
    @FXML
    private TableColumn<Evenement,Date> colDate;
    @FXML
    private TableColumn<Evenement,String> colQRcode;
    @FXML
    private TableColumn<Evenement,String> colImage;
    @FXML
    private TableColumn<Evenement,String> colLieu;
    @FXML
    private TableColumn<Evenement,String> colDescription;
    @FXML
    private TableColumn<Evenement,String> colNomEntreprise;
    @FXML
    private Button modifier;
    @FXML
    private Button retour;
    @FXML
    private TextField tfRechercheTitre;
    @FXML
    private Button btnChercher;
    @FXML
    private Label test;
    private ServiceEvenement service;
    private Evenement evenement;
    private ObservableList<Evenement> ResultatRecherche;



   
    private String TitreE;
    private Evenement originalEvenement;
    @FXML
    private DatePicker datePicker;
    
    public void setTitreE(String TitreE) {
        this.TitreE= TitreE;
        populateFields();
    }
    
     private void populateFields() {
        ServiceEvenement service = new ServiceEvenement();
        Evenement evenement = service.getOne(TitreE);

        if (evenement != null) {
            tfNomEntreprise.setText(String.valueOf(evenement.getId_entreprise()));
            tfTitre.setText(evenement.getTitre_evenement()); 
            datePicker.setValue(evenement.getDate_evenement().toLocalDate());
            tfQRcode.setText(evenement.getQRcode());
            tfImage.setText(evenement.getImage_evenement());
           } else {
            
        }
    }
     
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        service = new ServiceEvenement();

        ResultatRecherche = FXCollections.observableArrayList();
        colTitre.setCellValueFactory(new PropertyValueFactory("titre_evenement"));
        colDate.setCellValueFactory(new PropertyValueFactory("date_evenement"));
        colQRcode.setCellValueFactory(new PropertyValueFactory("QRcode"));
        colImage.setCellValueFactory(new PropertyValueFactory("image_evenement"));
        colLieu.setCellValueFactory(new PropertyValueFactory("lieu_evenement"));
        colDescription.setCellValueFactory(new PropertyValueFactory("description_evenement"));
        colNomEntreprise.setCellValueFactory(new PropertyValueFactory("id_entreperise"));
        if (originalEvenement != null) {
            tfTitre.setText(originalEvenement.getTitre_evenement()); 
            tfQRcode.setText(originalEvenement.getQRcode());
            tfImage.setText(originalEvenement.getImage_evenement());
            tfLieu.setText(originalEvenement.getLieu_evenement());
            tfDescription.setText(originalEvenement.getDescription_evenement());

            if (originalEvenement.getDate_evenement() != null) {
                LocalDate localDate = originalEvenement.getDate_evenement().toLocalDate();
                datePicker.setValue(localDate);
            }
        } else {
            test.setText("Evenement n'existe pas");
        }
        
    }  
    
    
    private boolean isValidTitreEvenement(String titre) {
        return service.getOne(titre) != null;
    } 
   
    
    @FXML
    private void btnRechercher(ActionEvent event) {
        String titre = tfRechercheTitre.getText();
        System.out.println(service != null);
        if (isValidTitreEvenement(titre)) {
            evenement = service.getOne(titre);
            List<Evenement> evenements = new ArrayList();
            evenements.add(evenement);
            System.out.println(evenements);
            ResultatRecherche.clear();
            ResultatRecherche.addAll(evenements);
            tvModifierEvenement.setItems(ResultatRecherche);
            displaytvModifierEvenement(evenement);
        } else {
            test.setText("Évènement introuvable");
            //clear.tvModifierEvenement();
        }
    }

    @FXML
    private void btnModifier(ActionEvent event) {
        try {
            int id_entreprise = Integer.parseInt(tfNomEntreprise.getText());
            String titre_evenement = tfTitre.getText();
            LocalDate localDate = datePicker.getValue();
            String QRcode = tfQRcode.getText();
            String image_evenement = tfImage.getText();
            String lieu_evenement = tfLieu.getText();
            String description_evenement = tfDescription.getText();

            // Check if required fields are empty
            if (titre_evenement.isEmpty() || description_evenement.isEmpty()) {
                test.setText("Entrer tous les champs");
            } else {
                Date date_evenement = null;
                if (localDate != null) {
                    date_evenement = Date.valueOf(localDate);
                } else {
                    test.setText("Entrer la date");
                }
              //  ServiceEvenement service = new ServiceEvenement();

                //Evenement evnt = new Evenement(id_entreprise, titre_evenement, date_evenement, QRcode, image_evenement, lieu_evenement, description_evenement);
                Evenement evnt = new Evenement(evenement.getId_evenement(),id_entreprise, evenement.getId_participant(), titre_evenement, date_evenement, QRcode, image_evenement, lieu_evenement, description_evenement, lieu_evenement);

                service.modifier(evnt);

                test.setText("Evenement ajouté avec succé");

                populateFields();
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            test.setText("Invalide ajout! Entrer valid champs");
        }
    }  


    @FXML
    private void btnRetour(ActionEvent event) {
         try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AccueilFXML.fxml"));
            Parent root = loader.load();
            Scene accueilFXMLScene = new Scene(root);
            Stage stage = (Stage) retour.getScene().getWindow();
            stage.setScene(accueilFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void displaytvModifierEvenement(Evenement evenement) {
    tfTitre.setText(evenement.getTitre_evenement());
    datePicker.setValue(evenement.getDate_evenement().toLocalDate());
    tfQRcode.setText(evenement.getQRcode());
    tfImage.setText(evenement.getImage_evenement());
    tfLieu.setText(evenement.getLieu_evenement());
    tfDescription.setText(evenement.getDescription_evenement());
    tvModifierEvenement.getSelectionModel().select(evenement);
    }

    private void cleartvModifierEvenement() {
        tfTitre.clear();
        datePicker.setValue(null);
        tfQRcode.clear();
        tfImage.clear();
        tfLieu.clear();
        tfDescription.clear();
    }

    
        
}


   
  



