/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.edu.forgreenerindustry.gui;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import tn.edu.forgreenerindustry.entities.Evenement;
import tn.edu.forgreenerindustry.services.ServiceEvenement;

/**
 * FXML Controller class
 *
 * @author milou
 */
public class SupprimerEvenementFXMLController implements Initializable {

    @FXML
    private TableColumn<Evenement, String> colTitre;
    @FXML
    private TableColumn<Evenement, Date> colDate;
    @FXML
    private TableColumn<Evenement, String> colQRcode;
    @FXML
    private TableColumn<Evenement, String> colImage;
    @FXML
    private TableColumn<Evenement, String> colLieu;
    @FXML
    private TableColumn<Evenement, String> colDescription;
    @FXML
    private TableColumn<Evenement, String> colNomEntreprise;
    @FXML
    private Button supprimer;
    @FXML
    private TableView<Evenement> tvSupprimerEvenement;
    @FXML
    private Button retour;
    private ServiceEvenement service;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    colTitre.setCellValueFactory(new PropertyValueFactory("titre_evenement"));
    colDate.setCellValueFactory(new PropertyValueFactory("date_evenement"));
    colQRcode.setCellValueFactory(new PropertyValueFactory("QRcode"));
    colImage.setCellValueFactory(new PropertyValueFactory("image_evenement"));
    colLieu.setCellValueFactory(new PropertyValueFactory("lieu_evenement"));
    colDescription.setCellValueFactory(new PropertyValueFactory("description_evenement"));
    colNomEntreprise.setCellValueFactory(new PropertyValueFactory("id_entreperise"));
   
    service = new ServiceEvenement();
    populateTvSupprimerEvenement();
    
    }  
    
    
    private void populateTvSupprimerEvenement() {
        List<Evenement> evenements = service.getAll(new Evenement());
        tvSupprimerEvenement.setItems(FXCollections.observableArrayList(evenements));
    }
    
    @FXML
    private void btnSupprimer(ActionEvent event) {
        Evenement selectedEvenement = tvSupprimerEvenement.getSelectionModel().getSelectedItem();
        if (selectedEvenement != null) {
            service.supprimer(selectedEvenement.getId_evenement());
            populateTvSupprimerEvenement(); // Refresh list
        }
    }

    @FXML
    private void btnRetour(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AccueilFXML.fxml"));
            Parent root = loader.load();
            Scene accueilFXMLScene = new Scene(root);
            Stage stage = (Stage) retour.getScene().getWindow();
            stage.setScene(accueilFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    

    

    
    
}
