/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.edu.forgreenerindustry.gui;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import tn.edu.forgreenerindustry.entities.Investissement;
import tn.edu.forgreenerindustry.services.ServiceInvestissement;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;


/**
 * FXML Controller class
 *
 * @author milou
 */
public class AjouterInvestissementFXMLController implements Initializable {
   
    @FXML
    private TextField tfMontant;
    @FXML
    private TextField tfDuree;
    @FXML
    private TextField tfDetails;
    @FXML
    private ComboBox<Integer> cbStatus;
    @FXML
    private TextField tfInvestisseur;
    @FXML
    private TextField tfNomEntreprise;
    @FXML
    private TableView<Investissement> tvAjouterInvestissement;
    @FXML
    private TableColumn<Investissement, String> colMontant;
    @FXML
    private TableColumn<Investissement, Date> colDate;
    @FXML
    private TableColumn<Investissement, String> colDuree;
    @FXML
    private TableColumn<Investissement, String> colDetails;
    @FXML
    private TableColumn<Investissement, String> colStatus;
    @FXML
    private TableColumn<Investissement, String> colInvestisseur;
    @FXML
    private TableColumn<Investissement, String> colNomEntreprise;
    @FXML
    private Button ajouter;
    @FXML
    private Button retour;
    @FXML
    private DatePicker datePicker;
    @FXML
    private Label test;
    
    private ServiceInvestissement service;
    


    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    colMontant.setCellValueFactory(new PropertyValueFactory("montant"));
    colDate.setCellValueFactory(new PropertyValueFactory("date_debut_investissement"));
    colDuree.setCellValueFactory(new PropertyValueFactory("duree_prevue"));
    colDetails.setCellValueFactory(new PropertyValueFactory("details"));
    colStatus.setCellValueFactory(new PropertyValueFactory("status"));
    colInvestisseur.setCellValueFactory(new PropertyValueFactory("id_investisseur"));
    colNomEntreprise.setCellValueFactory(new PropertyValueFactory("id_entreperise"));
    service = new ServiceInvestissement();
    cbStatus.getItems().addAll(
        1,
        0,
        -1
    );
    loadInvestissementData();
    } 
    

    
    public void loadInvestissementData() {
        ObservableList<Investissement> evenements = FXCollections.observableArrayList(service.getAll(null));
        tvAjouterInvestissement.setItems(evenements);
    }

    @FXML
    private void btnAjouter(ActionEvent event) {
        try {
            int id_entreprise = Integer.parseInt(tfNomEntreprise.getText());
            int id_investisseur = Integer.parseInt(tfInvestisseur.getText());
            double montant = Double.parseDouble(tfMontant.getText());
            LocalDate localDate = datePicker.getValue();
            String duree = tfDuree.getText();
            String details = tfDetails.getText();
            int status = cbStatus.getValue();
            

            // Check if required fields are empty
            if (details.isEmpty() || duree.isEmpty()) {
                test.setText("Entrer tous les champs");
            } else {
                Date date_investissement = null;
                if (localDate != null) {
                    date_investissement = Date.valueOf(localDate);
                } else {
                    test.setText("Entrer la date");
                }
              //  ServiceInvestissement service = new ServiceInvestissement();

                Investissement evenement = new Investissement(id_investisseur, id_entreprise, montant, date_investissement,duree,details,status);

                service.ajouter(evenement);

                test.setText("Investissement ajouté avec succé");

                loadInvestissementData();
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            test.setText("Invalide ajout! Entrer valid champs");
        }
    }  



    @FXML
    private void btnRetour(ActionEvent event) {
          try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AccueilFXML.fxml"));
            Parent root = loader.load();
            Scene accueilFXMLScene = new Scene(root);
            Stage stage = (Stage) retour.getScene().getWindow();
            stage.setScene(accueilFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }    
}



