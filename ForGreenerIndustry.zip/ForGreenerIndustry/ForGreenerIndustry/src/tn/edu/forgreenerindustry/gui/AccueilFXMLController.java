/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.edu.forgreenerindustry.gui;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import rsscreator.ui.resourses.filesHandler;
import javafx.scene.text.TextFlow;
import rsscreator.ui.main.FXMLDocumentController;
import static rsscreator.ui.main.FXMLDocumentController.createFeedListItem;
import rsscreator.ui.resourses.FeedMessage;


/**
 * FXML Controller class
 *
 * @author milou
 */
public class AccueilFXMLController implements Initializable {

    @FXML
    private Button ajouterEvenement;
    @FXML
    private Button modifierEvenement;
    @FXML
    private Button supprimerEvenement;
    @FXML
    private Button chercherEvenement;
    @FXML
    private Button afficherEvenement;
    @FXML
    private Button ajouterInvestissement;
    @FXML
    private Button modifierInvestissement;
    @FXML
    private Button supprimerInvestissement;
    @FXML
    private Button chercherInvestissement;
    @FXML
    private Button afficherInvestissement;
    @FXML
    private ListView<TextFlow> listView;
    public static ListView<TextFlow> myList;


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL location, ResourceBundle rb) {
        
        myList = listView;
        try {
                URL url = new URL("https://www.finance-investissement.com/nouvelles/feed/");
                filesHandler.importFrom(url);
            } catch (MalformedURLException ex) {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }

    }    

    @FXML
    private void btnAjouterEvenement(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AjouterEvenementFXML.fxml"));
            Parent root = loader.load();
            Scene ajouterEvenementFXMLScene = new Scene(root);
            Stage stage = (Stage) ajouterEvenement.getScene().getWindow();
            stage.setScene(ajouterEvenementFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void btnModifierEvenement(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ModifierEvenementFXML.fxml"));
            Parent root = loader.load();
            Scene modifierEvenementFXMLScene = new Scene(root);
            Stage stage = (Stage) modifierEvenement.getScene().getWindow();
            stage.setScene(modifierEvenementFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void btnSupprimerEvenement(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("SupprimerEvenementFXML.fxml"));
            Parent root = loader.load();
            Scene supprimerEvenementFXMLScene = new Scene(root);
            Stage stage = (Stage) supprimerEvenement.getScene().getWindow();
            stage.setScene(supprimerEvenementFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void btnChercherEvenement(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ChercherEvenementFXML.fxml"));
            Parent root = loader.load();
            Scene chercherEvenementFXMLScene = new Scene(root);
            Stage stage = (Stage) chercherEvenement.getScene().getWindow();
            stage.setScene(chercherEvenementFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void btnAfficherEvenement(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("GetAllEvenementFXML.fxml"));
            Parent root = loader.load();
            Scene afficherEvenementFXMLScene = new Scene(root);
            Stage stage = (Stage) afficherEvenement.getScene().getWindow();
            stage.setScene(afficherEvenementFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void btnAjouterInvestissement(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AjouterInvestissementFXML.fxml"));
            Parent root = loader.load();
            Scene ajouterInvestissementFXMLScene = new Scene(root);
            Stage stage = (Stage) ajouterInvestissement.getScene().getWindow();
            stage.setScene(ajouterInvestissementFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }

    @FXML
    private void btnModifierInvestissement(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ModifierInvestissementFXML.fxml"));
            Parent root = loader.load();
            Scene modifierInvestissementFXMLScene = new Scene(root);
            Stage stage = (Stage) modifierInvestissement.getScene().getWindow();
            stage.setScene(modifierInvestissementFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void btnSupprimerInvestissement(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("SupprimerInvestissementFXML.fxml"));
            Parent root = loader.load();
            Scene supprimerInvestissementFXMLScene = new Scene(root);
            Stage stage = (Stage) supprimerInvestissement.getScene().getWindow();
            stage.setScene(supprimerInvestissementFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void btnChercherInvestissement(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ChercherInvestissementFXML.fxml"));
            Parent root = loader.load();
            Scene chercherInvestissementFXMLScene = new Scene(root);
            Stage stage = (Stage) chercherInvestissement.getScene().getWindow();
            stage.setScene(chercherInvestissementFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void btnAfficherInvestissement(ActionEvent event) {
                try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("GetAllInvestissementFXML.fxml"));
            Parent root = loader.load();
            Scene afficherInvestissementFXMLScene = new Scene(root);
            Stage stage = (Stage) afficherInvestissement.getScene().getWindow();
            stage.setScene(afficherInvestissementFXMLScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void createList(){
        if (filesHandler.feed==null)return;
        myList.getItems().clear();
        for (FeedMessage msg:filesHandler.feed.getEntries()){
            myList.getItems().add(createFeedListItem(msg));
        }
    }
    
}
